
module.exports = () => {
    console.log("--------------- Update Task");
}