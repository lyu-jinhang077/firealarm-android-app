
import {
    StyleSheet
} from 'react-native';

export const g_colors = {
    lightBlue : "#77bbf4",
    blueWhite : "#adceff",
    darkBlue : "#295782",
    mainBackColor: "#272727",
}

export default styles = StyleSheet.create({
    
    mainContainer: {
        backgroundColor: g_colors.mainBackColor,
        padding: 16,
        flex: 1,
    },
    pageTitle: {
        fontSize: 24,
        color: g_colors.lightBlue,
        textAlign: 'center',
        padding: 10,
        paddingTop: 20,
        fontFamily: 'Arial',
        fontWeight: '800',

        textShadowColor: "rgba(0, 0, 0, 0.6)",
        textShadowOffset: {width: 3, height: 2},
        textShadowRadius: 5,
    },
    textInput: {
        borderColor: g_colors.darkBlue,
        borderRadius: 4,
        borderWidth: 2,
        textAlign: 'center',
        fontSize: 18,
        color: g_colors.blueWhite,
        marginTop: 10,
    },
    checkBox: {
        width: 20,
        height: 20,
        borderRadius: 3,
        borderColor: g_colors.darkBlue,
        borderWidth: 2,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 10,
    },
    bluePlaneText: {
        color: g_colors.lightBlue,
        fontSize: 16,
        fontWeight: '300',
    },
    buttonContainer: {
        backgroundColor: "#295699",
        borderRadius: 4,
        justifyContent: 'center',
        alignItems: 'center',
        paddingLeft: 30,
        paddingRight: 30,
        paddingTop: 10,
        paddingBottom: 10,
        marginTop: 10,
    },
    buttonText: {
        color: 'white',
        fontSize: 18,
        fontWeight: '400',

        textShadowColor: "rgba(0, 0, 0, 0.6)",
        textShadowOffset: {width: 1, height: 1},
        textShadowRadius: 1,
    },
    linkButtonContainer: {
        padding: 4,
        paddingBottom: 2,
        margin: 10,
        borderColor: "transparent",
        borderBottomColor: g_colors.lightBlue,
        borderBottomWidth: 1,
    },
    linkButtonText: {
        color: g_colors.lightBlue,
        fontSize: 16,
        fontWeight: '300',
    },
    heading: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
    },
    logoImage: {
        width: 40,
        height: 40,
        marginRight: 10,
        resizeMode: 'contain',
    },
    backButton: {
        position: 'absolute',
        left: 0,
        top: 0,
        paddingTop: 10,
        paddingBottom: 10,
        paddingLeft: 16,
        paddingRight: 16,
    },
    deviceListItem: {
        borderColor: g_colors.darkBlue,
        borderWidth: 2,
        borderRadius: 4,
        marginTop: 10,
    },
    deviceListItemTitle: {
        color: g_colors.blueWhite,
        fontSize: 16,
        flex: 1,
        padding: 8,
    },
    deviceListItemContent: {
        margin: 8,
        marginTop: 0,
        paddingTop: 8,
        borderWidth: 1,
        borderColor: "transparent",
        borderTopColor: g_colors.darkBlue,
    },
    deviceListItemItem: {
        fontSize: 16,
        color: g_colors.lightBlue,
        marginRight: 20,     
    },
    deviceListItemContentRow: {
        flexDirection: "row", 
        height: 30, 
        alignItems: "center",
    },
    navMenuButton: {
        position: 'absolute',
        right: 0,
        top: 0,
        paddingTop: 10,
        paddingBottom: 10,
        paddingLeft: 10,
        paddingRight: 10,
    },
    sideMenu: {
        position: 'absolute',
        right: -160,
        top: 0,
        width: 160,
        height: '100%',
        padding: 10,
        paddingTop: 20,
        backgroundColor: g_colors.mainBackColor,
    },
    sideMenuRow: {
        flexDirection: "row",
        alignItems: 'center',
        paddingTop: 10,
    },
    btnActivate: {
        resizeMode: 'stretch',
        width: 60,
        height: 60,
        marginTop: 10,
    }

});
