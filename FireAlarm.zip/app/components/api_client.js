
import fetch from 'react-native-fetch-polyfill';

const g_apiServer = "http://wapps.esy.es/firealarm/api/app-client.php";
// const g_apiServer = "http://192.168.2.12/firealarm/api/app-client.php";

export default class PaiApiClient {

    get(params) {
        let url = g_apiServer;
        let keys = Object.keys(params);
        for(let i = 0; i < keys.length; i++){
            if(i == 0){
                url += "?"
            }else {
                url += "&"
            }
            url += (keys[i] + "=" + encodeURIComponent(params[keys[i]]));
        }

        return fetch(url, {
            method: 'GET',
        }).then(response=>response.json())
    }

    post(params) {
        let formData = new FormData();
        for(let elem in params){
            formData.append(elem, params[elem]);
        }

        const fetchPromise = ()=>fetch(g_apiServer, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'multipart/form-data',
            },
            body: formData,
            timeout: 5000,
        });

        return fetchPromise().then(response=>{
            // console.debug(response);
            try{
                return response.json();
            } catch(e) {
                console.debug(response);
                console.debug("xxxxxxxxx Error: " + e && e.message);
                return {result:"error", data:"Unkown error"};
            }
        }).catch(e=>{
            console.debug(e);
            console.debug("xxxxxxxxx Error: " + e && e.message);
        });
    }

}