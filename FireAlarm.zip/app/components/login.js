/**
 * Fire Alarm application - login.js
 * Date: 2018/03/01
 * Author: TruePai
 */

import React, { Component } from 'react';
import {
    View,
    Text,
    TextInput,
    Check,
    TouchableOpacity,
    Button,
    Image,
    AsyncStorage,
    ToastAndroid,
} from 'react-native';

import LoadingView from './loadingView';

import PaiApiClient from './api_client';

import Icon from 'react-native-ionicons';

import styles, {g_colors} from './style';

const apiClient = new PaiApiClient();

export default class Login extends Component {

    constructor(props){
        super(props);
    
        this.state = {
            checkRememberMe: false,
            userName: '',
            password: '',
            bBusy: false,
        }
    }

    componentDidMount(){
        AsyncStorage.getItem("login", (err, result)=>{
            if(result){
                let login = JSON.parse(result);
                if(login.userName && login.password){
                    this.state.userName = login.userName;
                    this.state.password = login.password;
                    this.login();
                }
            }
        });
    }

    onTapRememberMe = () => {
        this.setState({
            checkRememberMe: !this.state.checkRememberMe
        });
    };

    login = () => {

        this.refs.input1.blur();
        this.refs.input2.blur();

        if(this.state.userName == ''){
            ToastAndroid.show("Username required", ToastAndroid.SHORT);
            return;
        }

        if(this.state.password == ''){
            ToastAndroid.show("Password required", ToastAndroid.SHORT);
            return;
        }

        this.setState({bBusy: true});
        let self = this;

        apiClient.post({
            cmd: "login",
            userName: this.state.userName,
            password: this.state.password,
        }).then(function(response){
            self.setState({
                bBusy: false,
            });
            if(response){
                // console.debug(response);
                if(response.result == "success"){
                    if(self.state.checkRememberMe){
                        AsyncStorage.setItem("login", JSON.stringify({
                            userName: self.state.userName,
                            password: self.state.password,
                        }));
                    }
                    ToastAndroid.show("Welcome", ToastAndroid.SHORT);
                    self.props.navigation.navigate("mainView", {data: response.data, userName: self.state.userName});
                } else if(response.result == "error") {
                    ToastAndroid.show(response.data, ToastAndroid.SHORT);
                } else {
                    ToastAndroid.show("Server error", ToastAndroid.SHORT);
                }
            } else {
                ToastAndroid.show("Request failed", ToastAndroid.SHORT);
            }
        })
        .catch(err=>{
            this.setState({
                bBusy: false,
            });
            ToastAndroid.show(err.message, ToastAndroid.SHORT);
        });

    };

    firstSetup = () => {
        this.props.navigation.navigate("firstSetup");
    };
    
    render() {

        return (
            <View style={{backgroundColor: g_colors.mainBackColor, flex: 1 }} >
                <View style={styles.mainContainer} >
                    <View style={styles.heading} >
                        {/* <Image source={require('../asset/app-logo.png')} style={styles.logoImage} /> */}
                        <Text style={styles.pageTitle} >Fire Alarm System</Text>
                    </View>
                    <TextInput ref="input1" style={styles.textInput} onChangeText={(userName)=>{this.setState({userName})}} placeholderTextColor={g_colors.darkBlue} underlineColorAndroid="transparent" placeholder="Username" />
                    <TextInput ref="input2" style={styles.textInput} onChangeText={(password)=>{this.setState({password})}} placeholderTextColor={g_colors.darkBlue} underlineColorAndroid="transparent" placeholder="Password" secureTextEntry={true} />
                    <View style={{marginTop: 10, flexDirection: 'row',  }} >
                        <View style={{flex: 1, }} />
                        <TouchableOpacity style={{flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', padding: 10, }} 
                        onPress={this.onTapRememberMe} >
                            <View style={styles.checkBox} >
                            {
                                this.state.checkRememberMe ?
                                <Icon name="md-checkmark" size={16} color={g_colors.blueWhite} />
                                : null
                            }
                            </View>
                            <Text style={styles.bluePlaneText} >Remember Me</Text>
                        </TouchableOpacity>
                    </View>
                    <TouchableOpacity style={styles.buttonContainer} onPress={this.login} >
                        <Text style={styles.buttonText} >Log In</Text>
                    </TouchableOpacity>
                    <View style={{flex: 1, }} />
                    <View style={{alignItems: 'center',}} >
                        <TouchableOpacity style={styles.linkButtonContainer} onPress={this.firstSetup} >
                            <Text style={styles.linkButtonText} >First-time Setup</Text>
                        </TouchableOpacity>
                    </View>
                </View>

                {
                    this.state.bBusy ?
                    <LoadingView /> : null
                }
            </View>);
    }
}