/**
 * Fire Alarm application - mainView.js
 * Date: 2018/03/01
 * Author: TruePai
 */

import React, { Component } from 'react';
import {
    View,
    Text,
    TextInput,
    Check,
    TouchableOpacity,
    Button,
    Image,
    ScrollView,
    BackHandler,
    AsyncStorage,
    Animated,
    Dimensions,
    Easing,
    ToastAndroid,
    AppRegistry,

    AppState,

} from 'react-native';

import Icon from 'react-native-ionicons';

import PushNotification from 'react-native-push-notification';

import LoadingView from './loadingView';

import ApiClient from './api_client';

import styles, {g_colors} from './style';

import BackgroundTimer from 'react-native-background-timer';

const images = {
    btn_normal: require("../asset/btn-normal.png"),
    btn_activated: require("../asset/btn-activate.png"),
};

const smokeLevel = {
    "1": {label: "Low", color: "#279438"},
    "2": {label: "Medium", color: "#107abf"},
    "3": {label: "High", color: "#da3c0d"},
};

const apiClient = new ApiClient();

export default class MainView extends Component {

    constructor(props){
        super(props);

        let userName = props.navigation.state.params['userName'];
        let data = props.navigation.state.params['data'];
        let devices = data.devices || [];

        let expandedDevs = [];
        if( devices.length > 0){
            expandedDevs.push(devices[0].id);
        }

        this.state = {
            bBusy: false,
            userId: data.userId,
            devices: devices,
            expandedDevs: expandedDevs,
            visibleSideMenu: false,
            userName: userName,
            updateTimer: null,
            waiting: false,
            appState: 'inactive',
        }

    }

    onBackPress = () => {
        return true;
    };

    componentDidMount() {
        BackHandler.addEventListener("hardwareBackPress", this.onBackPress);

        let warnings = [];
        let devices = this.state.devices;
        for(var d in devices) {
            let msg = "";
            if(parseInt(devices[d].temperature) >= 30) {
                msg += ("Temperature: " + devices[d].temperature + "°C, ");
            }
            if(parseInt(devices[d].smoke) >= 2 ) {
                msg += ("Smoke level: " + smokeLevel[devices[d].smoke]["label"] + "\n" );
            }
            if(msg != "") {
                warnings.push({
                    device: devices[d].deviceName,
                    message: msg
                });
            }

        }

        for(var w in warnings) {
            PushNotification.localNotification({
                title: "Fire alarm on device [" + warnings[w].device + "]",
                message: warnings[w].message
            });
        }

        let self = this;

        this.updateData();

        this.state.appState = 'active';

        AppState.addEventListener("change", this.onAppStateChange);

    }

    componentWillUnmount() {
        AppState.removeEventListener("change", this.onAppStateChange);
        BackHandler.removeEventListener("hardwareBackPress", this.onBackPress);
        try {
            this.state.updateTimer && BackgroundTimer.clearTimeout(this.state.updateTimer);
        } catch(e) {
            console.debug("xxxxxxxxx Error occurred: " + e && e.message);
        }
    }

    onAppStateChange = (state) => {
        this.state.appState = state;
    }

    checkNewAlert(devices) {

        let warnings = [];

        for(var i in devices) {
            var t = parseInt(devices[i].temperature);
            var s = parseInt(devices[i].smoke);
            var d = parseInt(devices[i].door);
            var dn = devices[i].doorNotify;
            var t0 = this.state.devices[i] ? parseInt(this.state.devices[i].temperature) : 0;
            var s0 = this.state.devices[i] ? parseInt(this.state.devices[i].smoke) : 0;
            var d0 = this.state.devices[i] ? parseInt(this.state.devices[i].door) : -1;

            let msg = "";
            if(t >= 30 && t != t0) {
                msg += ("Temperature: " + t + "°C, ");
            }
            if(s >= 2 && s != s0) {
                msg += ("Smoke level: " + smokeLevel[s]["label"] + ", " );
            }
            if(d != d0 && dn=="1" ) {
                msg += ("Door: " + (d == 1? "open" : "closed") );
            }
            if(msg != "") {
                warnings.push({
                    device: devices[i].deviceName,
                    message: msg
                });
            }
        }

        for(var w in warnings) {
            PushNotification.localNotification({
                title: "Fire alarm on device [" + warnings[w].device + "]",
                message: warnings[w].message
            });
        }
    }

    backgroundScheduleUpdate = (delay) => {
        this.state.updateTimer && BackgroundTimer.clearTimeout(this.state.updateTimer);
        this.state.updateTimer = BackgroundTimer.setTimeout(this.updateData, delay);
    }

    updateData = () => {

        let self = this;

        if(self.state.waiting) {
            self.backgroundScheduleUpdate();
            return;
        } 

        try {

            self.state.waiting = true;

            console.log("================== sending update request");

            apiClient.post({
                cmd: "refresh",
                userId: this.state.userId,
            }).then(function(response){
    
                console.log("================== updated data: " + JSON.stringify(response));
                self.state.waiting = false;                
               
                if(response){
                    if(response.result == "success") {
                        self.checkNewAlert(response.data);
                        if(self && self.state.appState=='active') self.setState({devices: response.data});
                        else self.state.devices = response.data;
                        self.backgroundScheduleUpdate(5000);
                    } else if(response.result == "error") {
                        self.backgroundScheduleUpdate(30000);
                        // ToastAndroid.show(response.data, ToastAndroid.SHORT);
                    } else {
                        self.backgroundScheduleUpdate(30000);
                        // ToastAndroid.show("Server error", ToastAndroid.SHORT);
                    }
                } else {
                    self.backgroundScheduleUpdate(30000);
                    // ToastAndroid.show("Request failed", ToastAndroid.SHORT);
                }
            })
            .catch((error)=>{
                console.log("===== error occurred during update: ");
                self.state.waiting = false;
                self.backgroundScheduleUpdate(30000);
                // ToastAndroid.show("Connection error occurred", ToastAndroid.SHORT);
            });
        } catch(err) {
            console.log("===== error occurred during update: " + err && err.message);
            self.state.waiting = false;
            self.backgroundScheduleUpdate(30000);
            // ToastAndroid.show("Error occurred: " + e && e.message, ToastAndroid.SHORT);
        }

    }

    addDevice = () => {
        this.onHideNavMenu();
        this.props.navigation.navigate("addDevice", {userId: this.state.userId});
    };

    customerDetail = () => {
        this.onHideNavMenu();
        this.props.navigation.navigate("customerDetail", {userId: this.state.userId});
    };

    onPressDev = (id) => {
        let expandedDevs = this.state.expandedDevs;
        let i = expandedDevs.indexOf(id);
        
        if(i >= 0) expandedDevs.splice(i, 1);
        else expandedDevs.push(id);

        this.setState({expandedDevs: expandedDevs});
    }

    enablePanic = (id) => {

        let devs = this.state.devices;
        let newVal = devs[id].panicButton == 1 ? "0" : "1";

        this.setState({bBusy: true});

        let self = this;

        self.state.waiting = true;

        apiClient.post({
            cmd: "enablePanic",
            deviceId: devs[id].deviceId,
            enabled: newVal,
        }).then(function(response){

            self && self.setState({bBusy: false});
            self.state.waiting = false;
           
            if(response){
                if(response.result == "success"){
                    devs[id].panicButton = newVal;
                    self && self.setState({devices: devs});
                    // ToastAndroid.show(response.data, ToastAndroid.SHORT);
                } else if(response.result == "error") {
                    ToastAndroid.show(response.data, ToastAndroid.SHORT);
                } else {
                    ToastAndroid.show("Server error", ToastAndroid.SHORT);
                }
            } else {
                ToastAndroid.show("Request failed", ToastAndroid.SHORT);
            }
        })
        .catch((error)=>{
            self && self.setState({bBusy: false});
            self.state.waiting = false;
            ToastAndroid.show("Connection error occurred", ToastAndroid.SHORT);
        });
        
    }

    activate = (id) => {
        // PushNotification.localNotification({
        //     message: "Test notification"
        // });

        let devs = this.state.devices;
        let newVal = devs[id].activated == 1 ? "0" : "1";

        this.setState({bBusy: true});

        let self = this;

        self.state.waiting = true;

        apiClient.post({
            cmd: "activate",
            deviceId: devs[id].deviceId,
            enabled: newVal,
        }).then(function(response){

            self && self.setState({bBusy: false});
            self.state.waiting = false;
           
            if(response){
                if(response.result == "success") {
                    devs[id].activated = newVal;
                    self && self.setState({devices: devs});
                    // ToastAndroid.show(response.data, ToastAndroid.SHORT);
                } else if(response.result == "error") {
                    ToastAndroid.show(response.data, ToastAndroid.SHORT);
                } else {
                    ToastAndroid.show("Server error", ToastAndroid.SHORT);
                }
            } else {
                ToastAndroid.show("Request failed", ToastAndroid.SHORT);
            }
        })
        .catch(err=>{
            self && self.setState({bBusy: false});
            self.state.waiting = false;
            ToastAndroid.show(err.message, ToastAndroid.SHORT);
        });
    }

    notifyDoorChange = (id) => {
        let devs = this.state.devices;
        let newVal = devs[id].doorNotify == 1 ? "0" : "1";

        this.setState({bBusy: true});

        let self = this;

        self.state.waiting = true;

        apiClient.post({
            cmd: "doorNotify",
            deviceId: devs[id].deviceId,
            enabled: newVal,
        }).then(function(response){

            self && self.setState({bBusy: false});
            self.state.waiting = false;
           
            if(response){
                if(response.result == "success") {
                    devs[id].doorNotify = newVal;
                    self && self.setState({devices: devs});
                    // ToastAndroid.show(response.data, ToastAndroid.SHORT);
                } else if(response.result == "error") {
                    ToastAndroid.show(response.data, ToastAndroid.SHORT);
                } else {
                    ToastAndroid.show("Server error", ToastAndroid.SHORT);
                }
            } else {
                ToastAndroid.show("Request failed", ToastAndroid.SHORT);
            }
        })
        .catch(err=>{
            self && self.setState({bBusy: false});
            self.state.waiting = false;
            ToastAndroid.show(err.message, ToastAndroid.SHORT);
        });
    }

    onShowNavMenu = () => {
        this.setState({visibleSideMenu: true});
        this.refs.sideMenu.show();
    }

    onHideNavMenu = () => {
        this.setState({visibleSideMenu: false});
        this.refs.sideMenu.hide();
    }

    logOut = () => {
        AsyncStorage.removeItem("login");
        this.props.navigation.goBack();
    }
    
    render() {

        console.log("======================== render()");

        try{
        
        let expandedDevs = this.state.expandedDevs;

        return (
            <View style={{backgroundColor: g_colors.mainBackColor, flex: 1 }} >
                <ScrollView keyboardShouldPersistTaps="always" style={styles.mainContainer} >
                    <View style={styles.heading} >
                        {/* <Image source={require('../asset/app-logo.png')} style={styles.logoImage} /> */}
                        <Text style={styles.pageTitle} >Fire Alarm System</Text>
                    </View>

                    {
                        this.state.devices.map((dev, id)=>{
                            let expanded = expandedDevs.includes(dev.id);
                            return (
                                <View style={styles.deviceListItem} key={id} >
                                    <View style={{flexDirection: 'row', }} >
                                        <Text style={styles.deviceListItemTitle} >
                                            {dev['deviceName']}
                                            {expanded ? " (id: " + dev['deviceId'] + ")" : ""}
                                        </Text>
                                        <TouchableOpacity style={{padding: 8, width: 40, }} onPress={()=>this.onPressDev(dev.id)} >
                                            <Icon name={expanded ? "ios-arrow-dropup" : "ios-arrow-dropdown" }  
                                                size={24} color={g_colors.blueWhite} />
                                        </TouchableOpacity>
                                    </View>
                                    {
                                        expanded ? 
                                        <View style={styles.deviceListItemContent} >
                                            <View style={styles.deviceListItemContentRow} >
                                                <Text style={styles.deviceListItemItem} >Smoke Level:</Text>
                                                {
                                                    dev.smoke && smokeLevel[dev.smoke] ?
                                                    <View style={{
                                                        backgroundColor: smokeLevel[dev.smoke].color,
                                                        borderRadius: 4,
                                                        paddingTop: 2,
                                                        paddingBottom: 2,
                                                        paddingLeft: 8,
                                                        paddingRight: 8,
                                                        }} >
                                                        <Text style={{color: "white", fontSize: 14, }} > 
                                                            {smokeLevel[dev.smoke].label} 
                                                        </Text>
                                                    </View>
                                                    :
                                                    <Text style={styles.deviceListItemItem} >--</Text>
                                                }
                                            </View>

                                            <View style={styles.deviceListItemContentRow} >
                                                <Text style={styles.deviceListItemItem} >IR Temperature:</Text>
                                                {
                                                    dev.temperature ?
                                                    <Text style={styles.deviceListItemItem} > {dev.temperature}℃ </Text>
                                                    :
                                                    <Text style={styles.deviceListItemItem} >--</Text>
                                                }
                                            </View>

                                            <View style={styles.deviceListItemContentRow} >
                                                <Text style={styles.deviceListItemItem} >Panic Button:</Text>

                                                {
                                                    dev.panicButton ? 
                                                    <TouchableOpacity onPress={()=>this.enablePanic(id)} 
                                                    style={{
                                                        width: 76,
                                                        height: 26,
                                                        flexDirection: "column",
                                                        alignItems: dev.panicButton==1?"flex-end":"flex-start",
                                                        borderRadius: 4,
                                                        backgroundColor: dev.panicButton==1?"#008800":"#555555",
                                                        }} >
                                                        <View style={{
                                                            width: 60,
                                                            height: 24,
                                                            margin: 1,
                                                            borderRadius: 4,
                                                            backgroundColor: "#dddddd",
                                                            alignItems: "center",
                                                            justifyContent: "center",
                                                        }} >
                                                            <Text style={{color: "#333333", fontSize: 11,}} >
                                                            {dev.panicButton==1 ? "Enabled" : "Disabled"}
                                                            </Text>
                                                        </View>
                                                    </TouchableOpacity>
                                                    : 
                                                    <Text style={styles.deviceListItemItem} >--</Text>
                                                }
                                                
                                            </View>

                                            <View style={styles.deviceListItemContentRow} >
                                                <Text style={styles.deviceListItemItem} >Door Status:</Text>
                                                {
                                                    dev.door ?
                                                    <View style={{flexDirection: 'row', marginLeft: 0, marginTop: 4,}} >
                                                        <Text style={styles.deviceListItemItem} > {dev.door==1?"Open":"Closed"}</Text>
                                                        <TouchableOpacity style={{flexDirection: 'row'}} onPress={()=>this.notifyDoorChange(id)} >
                                                            <View style={[styles.checkBox, {marginTop: 2, marginRight: 4,}]} >
                                                            {
                                                                dev.doorNotify==1 ?
                                                                <Icon name="md-checkmark" size={16} color={g_colors.blueWhite} />
                                                                : null
                                                            }
                                                            </View>
                                                            <Text style={[styles.bluePlaneText,{fontSize:14,marginTop:3,}]} >Notification</Text>
                                                        </TouchableOpacity>
                                                    </View>
                                                    :
                                                    <Text style={styles.deviceListItemItem} >--</Text>
                                                }
                                            </View>
                                            

                                            <View style={{justifyContent:'center',alignItems:'center'}} >
                                                <TouchableOpacity onPress={()=>this.activate(id)}>
                                                {
                                                    dev.activated==1?
                                                    <Image style={styles.btnActivate} source={images.btn_activated} />
                                                    :
                                                    <Image style={styles.btnActivate} source={images.btn_normal} />
                                                }
                                                </TouchableOpacity>
                                                <Text style={{
                                                    color: g_colors.lightBlue,
                                                    fontSize: 14,
                                                }} >
                                                Press to {dev.activated==1?"de":""}activate
                                                </Text>
                                            </View>
                                        </View> : null
                                    }
                                </View>);
                        })
                    }

                    <View style={{height: 30, }} />
                    
                </ScrollView>
              
                <TouchableOpacity style={styles.navMenuButton} onPress={this.onShowNavMenu} >
                    <Icon size={30} name="ios-menu" color={g_colors.lightBlue} />
                </TouchableOpacity>

                {
                    this.state.visibleSideMenu ?
                    <TouchableOpacity style={{
                        backgroundColor: "rgba(0, 0, 0, 0.6)",
                        position: 'absolute',
                        left: 0,
                        right: 0,
                        top: 0,
                        bottom: 0,
                    }} onPress={this.onHideNavMenu} />
                    : null
                }

                <SideMenu ref="sideMenu" parent={this} />

                {
                    this.state.bBusy ? <LoadingView /> : null
                }

            </View>);

        } catch(e) {
            console.log(e.message);
            return <View />
        }
    }
}

class SideMenu extends Component {

    width = 160;

    constructor(props){
        super(props);
        this.state = {
            parent: props.parent,
            rightValue: new Animated.Value(-this.width),
            
        }

    }

    componentDidMount() {
        // Animated.timing(
        //     this.state.rightValue, {
        //         toValue: 0,
        //         duration: 100,
        //     }
        // ).start();
    }

    show() {
        Animated.timing(
            this.state.rightValue, {
                toValue: 0,
                duration: 100,
            }
        ).start();
    }

    hide() {
        Animated.timing(
            this.state.rightValue, {
                toValue: -this.width,
                duration: 100,
            }
        ).start();
    }

    render() {
        return (
            <Animated.View style={[styles.sideMenu, {right: this.state.rightValue}]} >
                <View style={[styles.sideMenuRow, {justifyContent: "center", paddingBottom: 10, }]} >
                    <Icon name="md-person" size={20} color={g_colors.lightBlue} />
                    <Text style={{color: g_colors.lightBlue, fontSize: 14, paddingLeft: 6, paddingRight: 10, }} > {this.state.parent.state.userName} </Text>
                </View>
                <TouchableOpacity style={styles.sideMenuRow} onPress={this.state.parent.addDevice} >
                    <Icon name="md-add-circle" size={20} color={g_colors.blueWhite} />
                    <Text style={{color: g_colors.blueWhite, fontSize: 14, paddingLeft: 4, flex: 1, }} > Add Device </Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.sideMenuRow} onPress={this.state.parent.customerDetail} >
                    <Icon name="ios-mail" size={20} color={g_colors.blueWhite} />
                    <Text style={{color: g_colors.blueWhite, fontSize: 14, paddingLeft: 4, flex: 1, }} > Customer Details </Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.sideMenuRow} onPress={this.state.parent.logOut} >
                    <Icon name="md-log-out" size={20} color={g_colors.blueWhite} />
                    <Text style={{color: g_colors.blueWhite, fontSize: 14, paddingLeft: 4, flex: 1, }} > Log Out </Text>
                </TouchableOpacity>
            </Animated.View>
        );
    }
}