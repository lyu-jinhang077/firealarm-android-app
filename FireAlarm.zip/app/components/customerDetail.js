/**
 * Fire Alarm application - customerDetail.js
 * Date: 2018/03/24
 * Author: TruePai
 */

import React, { Component } from 'react';
import {
    View,
    Text,
    TextInput,
    Check,
    TouchableOpacity,
    Button,
    Image,
    ScrollView,
    ToastAndroid,
} from 'react-native';

import Icon from 'react-native-ionicons';

import LoadingView from './loadingView';

import PaiApiClient from './api_client';

import styles, {g_colors} from './style';

const apiClient = new PaiApiClient();

export default class CustomerDetail extends Component {

    constructor(props){
        super(props);

        let userId = props.navigation.state.params["userId"];
    
        this.state = {
            fullName: '',
            address: '',
            bBusy: true,
            userId: userId,
        }
    }

    componentDidMount() {

        let self = this;

        apiClient.post({
            cmd: "getDetail",
            userId: this.state.userId,
        }).then(function(res) {
            self.setState({bBusy: false});
            var msg = '';
            if(!res) {
                msg = "Unknown error occurred - null response";
            } else if (res.result == 'success') {
                self.setState({
                    fullName: res.data["fullName"],
                    address: res.data["address"],
                });
            } else if (res.result == "error") {
                msg = res.data;
            } else {
                msg = "Unknown error occurred";
            }

            if(msg != '') ToastAndroid.show(msg, ToastAndroid.SHORT);

        }).catch(function(err) {
            self.setState({bBusy: false});
            console.log("======== customer detail save error! =========" + err.message);
            ToastAndroid.show(err.message, ToastAndroid.LONG);
        });
    }

    saveDetail = () => {

        this.setState({
            bBusy: true,
        });

        let self = this;

        apiClient.post({
            cmd: 'saveDetail',
            userId: this.state.userId,
            fullName: this.state.fullName,
            address: this.state.address,
        }).then(function(res){
            self.setState({
                bBusy: false,
            });

            let msg = "";
            if (res == null){
                msg = "Error occurred";
            }
            else if (res.result == "success"){
                msg = "Customer detail updated";
            } else if (res.result == "error") {
                msg = res.data;
            }

            ToastAndroid.show(msg, ToastAndroid.SHORT);
        })
        .catch(function(err){
            console.log("==========");
            self.setState({
                bBusy: false,
            });
            ToastAndroid.show(err.message, ToastAndroid.SHORT);
        });
    };

    onBack = () => {
        this.props.navigation.goBack();
    }
    
    render() {
        return (
            <View style={{backgroundColor: g_colors.mainBackColor, flex: 1 }} >
                <ScrollView keyboardShouldPersistTaps="always" style={styles.mainContainer} >
                    <View style={styles.heading} >
                        {/* <Image source={require('../asset/app-logo.png')} style={styles.logoImage} /> */}
                        <Text style={styles.pageTitle} >Customer Details</Text>
                    </View>
                  
                    {
                        this.state.userId != 0 ?
                        <View>
                            <TextInput style={styles.textInput} onChangeText={(fullName)=>{this.setState({fullName})}} value={this.state.fullName} placeholderTextColor={g_colors.darkBlue} underlineColorAndroid="transparent" placeholder="Enter Name" />
                            <TextInput style={styles.textInput} onChangeText={(address)=>{this.setState({address})}} value={this.state.address} placeholderTextColor={g_colors.darkBlue} underlineColorAndroid="transparent" placeholder="Enter Address" />
                            
                            <TouchableOpacity style={styles.buttonContainer} onPress={this.saveDetail} >
                                <Text style={styles.buttonText} >Save</Text>
                            </TouchableOpacity>
                        </View>
                        :
                        null
                    }
                    
                </ScrollView>

                <TouchableOpacity style={styles.backButton} onPress={this.onBack} >
                    <Icon size={30} name="ios-arrow-back" color={g_colors.lightBlue} />
                </TouchableOpacity>

                {
                    this.state.bBusy ? <LoadingView /> : null
                }
            </View>);
    }
}