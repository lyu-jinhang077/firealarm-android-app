/**
 * Fire Alarm application - root.js
 * Date: 2018/03/01
 * Author: TruePai
 */

import { StackNavigator } from 'react-navigation';
import Login from './login';
import FirstSetup from './firstSetup';
import MainView from './mainView';
import AddDevice from './addDevice';
import CustomerDetail from './customerDetail';

let Root = StackNavigator({
    login: {
        screen: Login,
        navigationOptions: {
            gesturesEnabled: false,
        },

    },
    firstSetup: {
        screen: FirstSetup,
        navigationOptions: {
            gesturesEnabled: false,
        }
    },
    mainView: {
        screen: MainView,
        navigationOptions: {
            gesturesEnabled: false,
        }
    },
    addDevice: {
        screen: AddDevice,
        navigationOptions: {
            gesturesEnabled: false,
        }
    },
    customerDetail: {
        screen: CustomerDetail,
        navigationOptions: {
            gesturesEnabled: false,
        }
    },

}, {
        mode: 'modal',
        headerMode: 'none',
        transitionConfig: () => ({
            screenInterpolator: sceneProps => {
                const { layout, position, scene } = sceneProps;
                const { index } = scene;
    
                const translateX = position.interpolate({
                    inputRange: [index - 1, index, index + 1],
                    outputRange: [layout.initWidth, 0, 0]
                });
    
                const opacity = position.interpolate({
                    inputRange: [index - 1, index - 0.99, index, index + 0.99, index + 1],
                    outputRange: [0, 1, 1, 0.3, 0]
                });
    
                return { opacity, transform: [{ translateX }] }
            }
        }),
        cardStyle: {
            backgroundColor: 'black',
        }
    });

export default Root;