/**
 * Fire Alarm application - firstSetup.js
 * Date: 2018/03/05
 * Author: TruePai
 */

import React, { Component } from 'react';
import {
    View,
    Text,
    TextInput,
    Check,
    TouchableOpacity,
    Button,
    Image,
    ScrollView,
    ToastAndroid,
} from 'react-native';

import Icon from 'react-native-ionicons';

import LoadingView from './loadingView';

import PaiApiClient from './api_client';

import styles, {g_colors} from './style';

const apiClient = new PaiApiClient();

export default class AddDevice extends Component {

    constructor(props){
        super(props);

        let userId = props.navigation.state.params["userId"];
    
        this.state = {
            deviceId: '',
            deviceName: '',
            bBusy: false,
            userId: userId,
        }
    }

    addDevice = () => {

        if(this.state.deviceId.trim() == '') {
            ToastAndroid.show("Please input device ID", ToastAndroid.SHORT);
            return;
        }

        let regEx = /^[0-9a-zA-Z]{4,8}$/g;
        if(!regEx.test(this.state.deviceId)){
            ToastAndroid.show("Device ID must be 4 to 8 characters of alphabets or numbers. (e.g. \"dev04\") ", ToastAndroid.LONG);
            return;
        }

        if(this.state.deviceName.trim() == '') {
            ToastAndroid.show("Please input device name", ToastAndroid.SHORT);
            return;
        }

        this.setState({
            bBusy: true,
        });

        let self = this;

        apiClient.post({
            cmd: 'addDevice',
            userId: this.state.userId,
            deviceId: this.state.deviceId,
            deviceName: this.state.deviceName,
        }).then(function(res){
            self.setState({
                bBusy: false,
            });

            let msg = "";
            if (res == null){
                msg = "Error occurred";
            }
            else if (res.result == "success"){
                msg = "Added device successfully";
                self.setState({
                    deviceId: "",
                    deviceName: "",
                });
            } else if (res.result == "error") {
                msg = res.data;
            } 
            ToastAndroid.show(msg, ToastAndroid.SHORT);
        })
        .catch(function(err){
            self.setState({
                bBusy: false,
            });
            ToastAndroid.show(err.message, ToastAndroid.SHORT);
        });
    };

    onBack = () => {
        this.props.navigation.goBack();
    }
    
    render() {
        return (
            <View style={{backgroundColor: g_colors.mainBackColor, flex: 1 }} >
                <ScrollView keyboardShouldPersistTaps="always" style={styles.mainContainer} >
                    <View style={styles.heading} >
                        {/* <Image source={require('../asset/app-logo.png')} style={styles.logoImage} /> */}
                        <Text style={styles.pageTitle} >Add Device</Text>
                    </View>
                  
                    {
                        this.state.userId != 0 ?
                        <View>
                            <TextInput style={styles.textInput} onChangeText={(deviceId)=>{this.setState({deviceId})}} value={this.state.deviceId} placeholderTextColor={g_colors.darkBlue} underlineColorAndroid="transparent" placeholder="Enter a Device's ID" />
                            <TextInput style={styles.textInput} onChangeText={(deviceName)=>{this.setState({deviceName})}} value={this.state.deviceName} placeholderTextColor={g_colors.darkBlue} underlineColorAndroid="transparent" placeholder="Enter a Device's Name" />
                            
                            <TouchableOpacity style={styles.buttonContainer} onPress={this.addDevice} >
                                <Text style={styles.buttonText} >Add Device</Text>
                            </TouchableOpacity>
                        </View>
                        :
                        null
                    }
                    
                </ScrollView>

                <TouchableOpacity style={styles.backButton} onPress={this.onBack} >
                    <Icon size={30} name="ios-arrow-back" color={g_colors.lightBlue} />
                </TouchableOpacity>

                {
                    this.state.bBusy ? <LoadingView /> : null
                }
            </View>);
    }
}