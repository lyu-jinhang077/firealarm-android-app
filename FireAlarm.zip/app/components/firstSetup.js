/**
 * Fire Alarm application - firstSetup.js
 * Date: 2018/03/01
 * Author: TruePai
 */

import React, { Component } from 'react';
import {
    View,
    Text,
    TextInput,
    Check,
    TouchableOpacity,
    Button,
    Image,
    ScrollView,
    ToastAndroid,
} from 'react-native';

import Icon from 'react-native-ionicons';

import LoadingView from './loadingView';

import PaiApiClient from './api_client';

import styles, {g_colors} from './style';

const apiClient = new PaiApiClient();

export default class FirstSetup extends Component {

    constructor(props){
        super(props);
    
        this.state = {
            userName: '',
            password: '',
            password2: '',
            deviceId: '',
            deviceName: '',
            bBusy: false,
            userId: 0,
        }
    }

    register = () => {

        if(this.state.userName.trim() == '') {
            ToastAndroid.show("Please input username", ToastAndroid.SHORT);
            return;
        }

        if(this.state.password.trim() == '') {
            ToastAndroid.show("Please input password", ToastAndroid.SHORT);
            return;
        }

        if(this.state.password != this.state.password2) {
            this.setState({
                password: '',
                password2: '',
            });
            ToastAndroid.show("Password mismatch! Please type again", ToastAndroid.SHORT);
            return;
        }

        this.setState({
            bBusy: true,
        });

        let self = this;

        apiClient.post({
            cmd: 'register',
            userName: this.state.userName,
            password: this.state.password,
        }).then(function(res){
            self.setState({
                bBusy: false,
            });

            let msg = "";
            if (res == null){
                msg = "Error occurred"
            }
            else if (res.result == "success"){
                self.setState({userId: res.data});
                msg = "Registered successfully"
            } else if (res.result == "error") {
                msg = res.data
            } 
            ToastAndroid.show(msg, ToastAndroid.SHORT);
        })
        .catch(function(err){
            self.setState({
                bBusy: false,
            });
            ToastAndroid.show(err.message, ToastAndroid.SHORT);
        });
    };

    addDevice = () => {

        if(this.state.deviceId.trim() == '') {
            ToastAndroid.show("Please input device ID", ToastAndroid.SHORT);
            return;
        }

        let regEx = /^[0-9a-zA-Z]{4,8}$/g;
        if(!regEx.test(this.state.deviceId)){
            ToastAndroid.show("Device ID must be 4 to 8 characters of alphabets or numbers ", ToastAndroid.LONG);
            return;
        }

        if(this.state.deviceName.trim() == '') {
            ToastAndroid.show("Please input device name", ToastAndroid.SHORT);
            return;
        }

        this.setState({
            bBusy: true,
        });

        let self = this;

        apiClient.post({
            cmd: 'addDevice',
            userId: this.state.userId,
            deviceId: this.state.deviceId,
            deviceName: this.state.deviceName,
        }).then(function(res){
            self.setState({
                bBusy: false,
            });

            let msg = "";
            if (res == null){
                msg = "Error occurred";
            }
            else if (res.result == "success"){
                msg = "Added device successfully";
                self.props.navigation.goBack();
            } else if (res.result == "error") {
                msg = res.data;
            } 
            ToastAndroid.show(msg, ToastAndroid.SHORT);
        })
        .catch(function(err){
            self.setState({
                bBusy: false,
            });
            ToastAndroid.show(err.message, ToastAndroid.SHORT);
        });
    };

    onBack = () => {
        this.props.navigation.goBack();
    }
    
    render() {
        return (
            <View style={{backgroundColor: g_colors.mainBackColor, flex: 1 }} >
                <ScrollView keyboardShouldPersistTaps="always" style={styles.mainContainer} >
                    <View style={styles.heading} >
                        {/* <Image source={require('../asset/app-logo.png')} style={styles.logoImage} /> */}
                        <Text style={styles.pageTitle} >First-time Setup</Text>
                    </View>
                    {
                        this.state.userId == 0 ?
                        <View>
                            <TextInput style={styles.textInput} onChangeText={(userName)=>{this.setState({userName})}} value={this.state.userName} placeholderTextColor={g_colors.darkBlue} underlineColorAndroid="transparent" placeholder="Enter a Username" />
                            <TextInput style={styles.textInput} onChangeText={(password)=>{this.setState({password})}} value={this.state.password} placeholderTextColor={g_colors.darkBlue} underlineColorAndroid="transparent" placeholder="Enter a Password" secureTextEntry={true} />
                            <TextInput style={styles.textInput} onChangeText={(password2)=>{this.setState({password2})}} value={this.state.password2} placeholderTextColor={g_colors.darkBlue} underlineColorAndroid="transparent" placeholder="Confirm Password" secureTextEntry={true} />
                            
                            <TouchableOpacity style={[styles.buttonContainer, {marginBottom: 20,}]} onPress={this.register} >
                                <Text style={styles.buttonText} >Register</Text>
                            </TouchableOpacity>
                        </View>
                        :
                        <View>
                            <Text style={{
                                color: g_colors.blueWhite,
                                fontSize: 16,
                                fontWeight: '300',
                                textAlign: 'center',
                                padding: 10,
                            }} >Username:{" " + this.state.userName}</Text>
                        </View>
                    }

                    {
                        this.state.userId != 0 ?
                        <View>
                            <TextInput style={styles.textInput} onChangeText={(deviceId)=>{this.setState({deviceId})}} placeholderTextColor={g_colors.darkBlue} underlineColorAndroid="transparent" placeholder="Enter a Device's ID" />
                            <TextInput style={styles.textInput} onChangeText={(deviceName)=>{this.setState({deviceName})}} placeholderTextColor={g_colors.darkBlue} underlineColorAndroid="transparent" placeholder="Enter a Device's Name" />
                            
                            <TouchableOpacity style={styles.buttonContainer} onPress={this.addDevice} >
                                <Text style={styles.buttonText} >Add Device</Text>
                            </TouchableOpacity>
                        </View>
                        :
                        null
                    }
                    
                </ScrollView>

                <TouchableOpacity style={styles.backButton} onPress={this.onBack} >
                    <Icon size={30} name="ios-arrow-back" color={g_colors.lightBlue} />
                </TouchableOpacity>

                {
                    this.state.bBusy ? <LoadingView /> : null
                }
            </View>);
    }
}