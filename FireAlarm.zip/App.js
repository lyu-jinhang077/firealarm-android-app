/**
 * Fire Alarm application - App.js
 * Date: 2018/03/01
 * Author: TruePai
 */

import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View
} from 'react-native';

import Root from './app/components/root';

export default class App extends Component {
  render() {
    return (
      <Root />
    );
  }
}
